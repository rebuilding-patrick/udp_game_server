Reliable UDP network for games in pure Python. A light-weight manager of connections for sending and recving data over UDP sockets. It works but still very much a WIP.
